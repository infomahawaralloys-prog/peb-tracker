-- ============================================
-- PEB PROJECT TRACKER - Database Schema
-- Run this in Supabase SQL Editor (one time)
-- ============================================

-- 1. Projects table
CREATE TABLE projects (
  id TEXT PRIMARY KEY,
  sn INTEGER NOT NULL,
  project_no TEXT NOT NULL,
  location TEXT NOT NULL,
  civil_dwg TEXT DEFAULT 'none' CHECK (civil_dwg IN ('none', 'in_progress', 'done')),
  ga_dwg TEXT DEFAULT 'none' CHECK (ga_dwg IN ('none', 'in_progress', 'done')),
  fab_dwg TEXT DEFAULT 'none' CHECK (fab_dwg IN ('none', 'in_progress', 'done')),
  sheet_dwg TEXT DEFAULT 'none' CHECK (sheet_dwg IN ('none', 'in_progress', 'done')),
  paint_coating TEXT DEFAULT '',
  status TEXT DEFAULT 'Pending' CHECK (status IN ('Pending', 'In Progress', 'On Hold', 'Completed', 'Dispatched')),
  job_no TEXT DEFAULT '',
  remarks TEXT DEFAULT '',
  drive_link TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Activity logs table
CREATE TABLE activity_logs (
  id BIGSERIAL PRIMARY KEY,
  username TEXT NOT NULL,
  role TEXT NOT NULL,
  project TEXT NOT NULL,
  action TEXT NOT NULL,
  old_value TEXT DEFAULT '',
  new_value TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Settings table
CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- 4. Insert default settings
INSERT INTO settings (key, value) VALUES
  ('editor_passcode', 'peb2026'),
  ('admin_passcode', 'admin2026');

-- 5. Insert your 12 projects
INSERT INTO projects (id, sn, project_no, location, civil_dwg, ga_dwg, fab_dwg, sheet_dwg, paint_coating, status, job_no) VALUES
  ('p01', 1, 'PB-015', 'Pathankot', 'done', 'done', 'done', 'done', '9002', 'In Progress', 'J26-01'),
  ('p02', 2, 'PB-022', 'Sangrur', 'done', 'done', 'none', 'done', 'DA Grey', 'In Progress', 'J26-02'),
  ('p03', 3, 'PB-010', 'Derabassi', 'done', 'done', 'none', 'none', 'DA Grey', 'Pending', ''),
  ('p04', 4, 'PB-012', 'Jammu', 'done', 'done', 'done', 'none', '9002', 'In Progress', 'J25-14'),
  ('p05', 5, 'PB-019', 'Varanasi', 'done', 'done', 'none', 'none', 'Red Oxide', 'In Progress', 'J26-03'),
  ('p06', 6, 'PB-020', 'West Africa', 'done', 'done', 'none', 'none', '', 'Pending', ''),
  ('p07', 7, 'PB-016', 'Kurali', 'done', 'none', 'none', 'none', '', 'Pending', ''),
  ('p08', 8, 'PB-018', 'Talamandi', 'done', 'none', 'in_progress', 'none', '7026', 'In Progress', ''),
  ('p09', 9, 'PB-023', 'M.G.G. (B.I)', 'in_progress', 'none', 'none', 'none', '', 'In Progress', ''),
  ('p10', 10, 'PB-024', 'Chunni', 'none', 'none', 'none', 'none', '', 'Pending', ''),
  ('p11', 11, 'PB-025', 'M.G.G.', 'none', 'none', 'none', 'none', '', 'Pending', ''),
  ('p12', 12, 'PB-026', 'Jalandhar', 'in_progress', 'none', 'none', 'none', '', 'In Progress', '');

-- 6. Enable real-time for projects table
ALTER PUBLICATION supabase_realtime ADD TABLE projects;

-- 7. Auto-update the updated_at column
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER projects_updated_at
  BEFORE UPDATE ON projects
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- 8. Allow public access (since we use passcode-based auth, not Supabase auth)
-- This is safe because the anon key only allows what these policies permit

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow all on projects" ON projects FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on activity_logs" ON activity_logs FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Allow all on settings" ON settings FOR ALL USING (true) WITH CHECK (true);
